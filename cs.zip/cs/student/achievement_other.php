<?php include 'connect.php'; ?>
<?php
echo "1";
if (!empty($_POST)) {
    if (($_FILES['certificate']['name'] != "")) {
        $uploaddir = 'upload/';
        $uploadfile = $uploaddir . basename($_FILES['certificate']['name']);
        echo "2";
        if (move_uploaded_file($_FILES['certificate']['tmp_name'], $uploadfile)) {
            $faculty_name = $_POST['faculty_name'];
            $eid = $_POST['eid'];
            $award = $_POST['achievement'];
            $issue = $_POST['issue'];
            $date = $_POST['date'];
            $venue = $_POST['venue'];
            echo "exe";
            $sql = "INSERT INTO achievementother VALUES ('','{$faculty_name}','{$eid}','{$achievement}','{$issue}','{$date}','{$venue}','{$uploadfile}')";
    if (mysqli_query($conn, $sql)) {
                header("Location: /cs/z/paper.php?status='sucess'");
            } else {
                header("Location: /cs/z/paper.php?status='failed'");
            }
        } else {
            header("Location: /cs/z/paper.php?status='upload failed'");
        }

           mysqli_close($conn);
       }
   }
   ?>

