<?php include 'connect.php'; ?>

<?php
if (!empty($_GET)) {
    $k = number_format($_GET['k']);
    $sql = "DELETE FROM `achievementcom` WHERE `achievementcom`.`ach_com_id` = '{$k}' ";
    echo $k;
    echo $sql;
    if (mysqli_query($conn, $sql)) {
        header("Location: /cs/z/data_achievement_com.php");
    }
}
?>